Staunton Chess Set in obj.

A chess set modeled in the traditional Staunton style. Modeled by me in Cinema 4D. Comments and suggestions are always welcome. Email me at h2dog1@digitalwood.us.

Directions: Unzip the files and import to your favorite 3D application that supports Wavefront Object format (.obj).

Copyright 2005, Robert Wood aka h2odog, www.digitalwood.us. For commercial or noncommercial use in renders and animation. Please do not redistribute the models without my permission.

Robert Wood, 2005